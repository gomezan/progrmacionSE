/* Definiciones generales */
#if !defined(VARIOS_H)

#define VARIOS_H

#include <stdio.h>

/* Valores booleanos */
#define SI	1
#define NO	0
#define TRUE  1
#define FALSE 0


#endif